package com.berkay.oyunceviri.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import com.berkay.oyunceviri.core.TokenAuth
import com.berkay.oyunceviri.core.TvProtocol
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONException
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.Collections

/**
 * Android TV tarafı:
 *  1) WebSocket sunucusu açar (telefondan altyazı metni gelir),
 *  2) NSD (mDNS) ile "_oyunceviri._tcp." servisini yayınlar, telefon IP'siz bulur,
 *  3) Gelen metni WindowManager overlay'i ile ekranın altına çizer.
 *
 * Mesaj protokolü (JSON, tek satır):
 *   {"type":"sub","text":"Merhaba"}   -> altyazıyı göster
 *   {"type":"clear"}                   -> altyazıyı gizle
 *   {"type":"style","size":28,"bg":70,"shadow":true} -> görünümü ayarla (kalıcı)
 * JSON olmayan düz metin de altyazı olarak gösterilir (test için).
 */
class OverlayService : Service() {

    companion object {
        const val PORT = TvProtocol.PORT
        const val SERVICE_TYPE = TvProtocol.SERVICE_TYPE
        const val ACTION_TEST = "com.berkay.oyunceviri.tv.TEST"
        const val ACTION_STOP = "com.berkay.oyunceviri.tv.STOP"
        /** Yeni kod üretildi: eski kodla bağlı herkesi at. */
        const val ACTION_KICK_ALL = "com.berkay.oyunceviri.tv.KICK_ALL"
        private const val TAG = "OyunCeviriTV"
        private const val AUTO_HIDE_MS = 15_000L
        private const val TEST_DELAY_MS = 10_000L
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var rootView: View? = null
    private var subtitleView: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private var server: SubtitleServer? = null
    /** Doğru kodla bağlanmış bağlantılar. Başkasından gelen mesajlar yok sayılır. */
    private val authed: MutableSet<WebSocket> = Collections.synchronizedSet(HashSet())
    private var nsd: NsdManager? = null
    private var regListener: NsdManager.RegistrationListener? = null

    private val hideRunnable = Runnable { hideSubtitle() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()

        if (intent?.action == ACTION_KICK_ALL) {
            // Yeni kod üretildi: eski kodla bağlı herkesi at
            server?.connections?.forEach { it.close(TvProtocol.CLOSE_UNAUTHORIZED, "Yeni kod") }
            authed.clear()
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay izni yok. Uygulamayı açıp talimata bak.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        if (rootView == null) createOverlay()
        if (server == null) startServer()
        if (regListener == null) registerNsd()

        if (intent?.action == ACTION_TEST) {
            // HDMI girişine geçmen için 10 sn bekler, sonra örnek altyazı gösterir
            main.postDelayed({
                showSubtitle("Test altyazısı: overlay bu ekranda çalışıyor")
            }, TEST_DELAY_MS)
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ovl", "Oyun Çeviri TV", NotificationManager.IMPORTANCE_LOW)
        )
        val notif = Notification.Builder(this, "ovl")
            .setContentTitle("Oyun Çeviri TV çalışıyor")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }

    // ---------------- WebSocket sunucusu ----------------

    private inner class SubtitleServer : WebSocketServer(InetSocketAddress(PORT)) {
        override fun onStart() {
            Log.i(TAG, "WebSocket sunucusu hazır: $PORT")
            connectionLostTimeout = 15
        }

        override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
            val provided = TvProtocol.tokenFromResource(handshake.resourceDescriptor)
            if (!TokenAuth.matches(TvToken.get(this@OverlayService), provided)) {
                Log.w(TAG, "Yetkisiz bağlantı reddedildi: ${conn.remoteSocketAddress}")
                conn.close(TvProtocol.CLOSE_UNAUTHORIZED, "Unauthorized")
                return
            }
            authed.add(conn)
            conn.send(TvProtocol.hello()) // telefon "bağlandı" saymak için bunu bekler
            Log.i(TAG, "Bağlandı: ${conn.remoteSocketAddress}")
        }

        override fun onClose(conn: WebSocket?, code: Int, reason: String?, remote: Boolean) {
            conn?.let { authed.remove(it) }
            Log.i(TAG, "Koptu: $code")
        }

        override fun onMessage(conn: WebSocket, message: String) {
            if (conn in authed) handleMessage(message)
        }

        override fun onError(conn: WebSocket?, ex: Exception) {
            Log.e(TAG, "WebSocket hatası", ex)
        }
    }

    private fun startServer() {
        server = SubtitleServer().also {
            it.setReuseAddr(true)
            it.setTcpNoDelay(true) // küçük mesajlar Nagle yüzünden beklemesin
            it.start()
        }
    }

    // WebSocket thread'inde çağrılır
    private fun handleMessage(raw: String) {
        try {
            val j = JSONObject(raw)
            when (j.optString("type")) {
                "sub" -> main.post { showSubtitle(j.optString("text")) }
                "clear" -> main.post { hideSubtitle() }
                "style" -> main.post { updateStyle(j) }
            }
        } catch (e: JSONException) {
            main.post { showSubtitle(raw) } // düz metin: test için
        }
    }

    // ---------------- NSD (mDNS) ----------------

    private fun registerNsd() {
        val manager = getSystemService(Context.NSD_SERVICE) as NsdManager
        nsd = manager
        val info = NsdServiceInfo().apply {
            serviceName = TvProtocol.SERVICE_NAME
            serviceType = SERVICE_TYPE
            port = PORT
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {
                Log.i(TAG, "NSD yayında: ${i.serviceName}")
            }

            override fun onRegistrationFailed(i: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "NSD kaydı başarısız: $errorCode")
            }

            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, errorCode: Int) {}
        }
        regListener = listener
        manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    // ---------------- Overlay ----------------

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LayoutInflater.from(this).inflate(R.layout.overlay_subtitle, null)
        val tv = root.findViewById<TextView>(R.id.subtitleText)
        root.visibility = View.GONE

        val bottomMargin = (resources.displayMetrics.heightPixels * 0.07f).toInt()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = bottomMargin
        }

        rootView = root
        subtitleView = tv
        overlayParams = lp
        wm.addView(root, lp)
        applyStyle()
    }

    private fun prefs() = getSharedPreferences("tv_cfg", MODE_PRIVATE)

    private fun updateStyle(j: JSONObject) {
        val e = prefs().edit()
            .putInt("size", j.optInt("size", 28).coerceIn(14, 72))
            .putInt("bg", j.optInt("bg", 70).coerceIn(0, 100))
            .putBoolean("shadow", j.optBoolean("shadow", true))
        // Sonraki alanlar isteğe bağlı: eski gönderenler (telefon) göndermezse mevcut değer korunur
        if (j.has("color")) e.putString("color", j.optString("color"))
        if (j.has("pos")) e.putInt("pos", j.optInt("pos", 7).coerceIn(0, 60))
        if (j.has("cover")) e.putInt("cover", j.optInt("cover", 0).coerceIn(0, 40))
        if (j.has("width")) e.putInt("width", j.optInt("width", 80).coerceIn(30, 100))
        e.apply()
        applyStyle()
    }

    private fun parseColor(value: String?): Int = try {
        Color.parseColor(value ?: "#FFFFFF")
    } catch (e: IllegalArgumentException) {
        Color.WHITE
    }

    /**
     * Yazı boyutu, renk, arka plan, gölge ve konum.
     * cover > 0 ise kutu sabit boyutlu olur: oyunun kendi altyazısının üstüne oturup onu kapatır.
     */
    private fun applyStyle() {
        val tv = subtitleView ?: return
        val root = rootView as? FrameLayout ?: return
        val p = prefs()
        val dm = resources.displayMetrics
        val sizeSp = p.getInt("size", 28)
        val bgPercent = p.getInt("bg", 70)
        val shadow = p.getBoolean("shadow", true)
        val cover = p.getInt("cover", 0)

        tv.textSize = sizeSp.toFloat()
        tv.setTextColor(parseColor(p.getString("color", "#FFFFFF")))
        tv.background = GradientDrawable().apply {
            setColor(Color.argb(255 * bgPercent / 100, 0, 0, 0))
            cornerRadius = 12f * dm.density
        }
        if (shadow) {
            tv.setShadowLayer(4f, 1.5f, 1.5f, 0xCC000000.toInt()) // hafif gölge
        } else {
            tv.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        }

        if (cover > 0) {
            root.setPadding(0, 0, 0, 0)
            tv.layoutParams = FrameLayout.LayoutParams(
                dm.widthPixels * p.getInt("width", 80) / 100,
                dm.heightPixels * cover / 100,
                Gravity.CENTER_HORIZONTAL
            )
            tv.maxLines = 4
        } else {
            val side = (96 * dm.density).toInt()
            root.setPadding(side, 0, side, 0)
            tv.layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL
            )
            tv.maxLines = 3
        }
        tv.gravity = Gravity.CENTER

        overlayParams?.let { lp ->
            lp.y = (dm.heightPixels * p.getInt("pos", 7) / 100f).toInt()
            try {
                wm.updateViewLayout(root, lp)
            } catch (_: Exception) {
            }
        }
    }

    private fun showSubtitle(text: String) {
        if (text.isBlank()) {
            hideSubtitle()
            return
        }
        subtitleView?.text = text
        rootView?.visibility = View.VISIBLE
        main.removeCallbacks(hideRunnable)
        main.postDelayed(hideRunnable, AUTO_HIDE_MS) // 'clear' kaybolursa takılı kalmasın
    }

    private fun hideSubtitle() {
        main.removeCallbacks(hideRunnable)
        rootView?.visibility = View.GONE
    }

    // ---------------- Temizlik ----------------

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try {
            regListener?.let { nsd?.unregisterService(it) }
        } catch (_: Exception) {
        }
        regListener = null
        try {
            server?.stop(500)
        } catch (_: Exception) {
        }
        server = null
        authed.clear()
        rootView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        rootView = null
        super.onDestroy()
    }
}
